<?php include "header.php";?>


<div class="content-wrapper">
    
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Sub Category</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item ">Category</li>
              <li class="breadcrumb-item active">Add Subcategory</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    

    <!-- Main content -->
    <section class="content">
    <div class="container">
           
       <div class="row">
           <div class="col-lg-3"></div>

             <div class="col-lg-6">
               <div class="card-header"></div>

             <div class="card-body">
               <form action="admin-code.php" method="post" enctype="multipart/form-data">

                
                  <div class="form-group">
                    <label for="">Category</label>
                    <select class="form-control" name="category">
                      <option>---Select Category---</option>
                    <?php
                      $catres=$admin_obj->list_category();
                        if(mysqli_num_rows($catres)>0){
                          while($catrow=mysqli_fetch_assoc($catres)){
                            ?>
                            <option>
                             <?php echo $catrow['category'];?>
                          </option>
                            <?php
                          }
                        }
                    ?>
                    </select>
                  </div>
                  <div class="form-group">
                   <label for="">Sub Category</label>
                   <input class="form-control" type="text" name="subcategory" placeholder="Enter the Sub-category Name">
                 </div>

                 <div class="form-group">
                   <label for="">Pics</label>
                   <input class="form-control" type="file" name="pic">
                 </div>
                      <input type="hidden" name="id">
                 <div>
                   <button type="submit" name="addsubcategory" class="btn btn-primary">Add </button>
                 </div>
               </form>
             </div>  

               <div class="card-footer"></div>
             </div>

           </div>

             <div class="col-lg-3"></div>
     </div>
    </section>
    <!-- /.content -->
  </div>





<?php include "footer.php";?>
<?php include "header.php";


?>

<div class="content-wrapper">
    
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Category</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item ">Category</li>
              <li class="breadcrumb-item active">Add-Category</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    

    <!-- Main content -->
    <section class="content">
      <div class="container">
       


          
        <div class="row">
            <div class="col-lg-3"></div>

              <div class="col-lg-6">
                <div class="card-header"></div>

              <div class="card-body">
                <form action="admin-code.php" method="post" enctype="multipart/form-data">

                  <div class="form-group">
                    <label for="">Category</label>
                    <input class="form-control" type="text" name="category" placeholder="Enter the Category Name">
                  </div>

                  <div class="form-group">
                    <label for="">Pics</label>
                    <input class="form-control" type="file" name="pic">
                  </div>
                    <input type="hidden" name="id" id="">
                  <div>
                    <button type="submit" name="btnadd" class="btn btn-primary" >Add </button>
                  </div>
                </form>
              </div>  

                <div class="card-footer"></div>
              </div>
 
            </div>

              <div class="col-lg-3"></div>
      </div>
          

        
    </section>
    <!-- /.content -->
</div>





<?php include "footer.php";?>
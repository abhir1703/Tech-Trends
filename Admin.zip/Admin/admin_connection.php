<?php 


    class admin_link{

        function __construct(){
            $this->connect=mysqli_connect("localhost","root","","cyber");
            session_start();
        }
        function admin_login($email,$pass){
            $sql="SELECT * FROM admin_login WHERE Email='$email' AND Password='$pass'";
            return mysqli_query($this->connect,$sql);
        }
        function admin_page(){
            $sql="SELECT * FROM user_data";
            return mysqli_query($this->connect,$sql);
        }
        function add_category($cat_name, $cat_pic){
            $sql="INSERT INTO add_category(category, pic) VALUES('$cat_name', '$cat_pic')";
            return mysqli_query($this->connect, $sql);
        }
        function display_category(){   
            $sql="SELECT * FROM add_category";
            return mysqli_query($this->connect, $sql);
        }
        function count_category(){   
            $sql="SELECT count(*) as total FROM add_category";
            return mysqli_query($this->connect, $sql);
        }
        function list_category(){
            $sql="SELECT * FROM add_category ";
            return mysqli_query($this->connect, $sql);
        }
        function add_sub_category( $sub_cat_name, $cat_name, $sub_cat_pic){
            $sql="INSERT INTO sub_category( subcategory, category, pic) VALUES( '$sub_cat_name', '$cat_name', '$sub_cat_pic')";
            return mysqli_query($this->connect, $sql);
        }
        function viewsubcategory(){
            $sql="SELECT * FROM sub_category";
            return mysqli_query($this->connect, $sql);
        }
        function count_subcategory(){
            $sql="SELECT count(*) as total FROM sub_category";
            return mysqli_query($this->connect, $sql);
        }
        function list_subcategory(){
            $sql="SELECT * FROM sub_category";
            return mysqli_query($this->connect, $sql);
        }
        function add_brands($brand_name, $sub_cat_name, $cat_name, $pic){
            $sql="INSERT INTO add_brand(brand, subcategory, category, pic)
             VALUES('$brand_name', '$sub_cat_name', '$cat_name', '$pic')";        
            return mysqli_query($this->connect, $sql);
        }
        function viewbrand(){
            $sql="SELECT * FROM add_brand";
            return mysqli_query($this->connect, $sql);
        }
        function count_brands(){
            $sql="SELECT count(*) as total FROM add_brand";
            return mysqli_query($this->connect, $sql);
        }
        function add_products($pro_name, $pro_title, $pro_slug, $pro_keyword, $pro_category,
            $pro_subcategory, $pro_brand, $pro_org_price, $pro_disc_price, $pro_shortdescription, $pro_longdescription, 
            $pro_size, $pro_color, $pro_gst, $pro_disc, $pro_deliverycharge, $pro_pic,  $pro_slider_pic){

            $sql="INSERT INTO `product`(`name`, `title`, `slug`, `keywords`, `category`, 
            `subcategory`, `brand`, `original_price`, discount_price, `short_description`, `long_description`, `size`, 
            `colors`, `gst`, discount, `delivery_charge`, `pic`, `slider_pic`) 
            VALUES('$pro_name', '$pro_title', '$pro_slug', '$pro_keyword', '$pro_category', 
            '$pro_subcategory', '$pro_brand', '$pro_org_price', '$pro_disc_price', '$pro_shortdescription', 
            '$pro_longdescription', '$pro_size', '$pro_color', '$pro_gst', '$pro_disc', 
            '$pro_deliverycharge', '$pro_pic', '$pro_slider_pic')";        
            return mysqli_query($this->connect, $sql);
        }
        function viewproduct(){
            $sql="SELECT * FROM product";
            return mysqli_query($this->connect, $sql);
        }
        function count_products(){
            $sql="SELECT count(*) as total FROM product";
            return mysqli_query($this->connect, $sql);
        }


        function deletecategory($id){
            $sql="DELETE FROM add_category where cat_id='$id' ";
            return mysqli_query($this->connect, $sql);
        }
        function deletesubcategory($id){
            $sql="DELETE FROM sub_category where id='$id' ";
            return mysqli_query($this->connect, $sql);
        }
        function deletebrand($id){
            $sql="DELETE FROM add_brand where id='$id' ";
            return mysqli_query($this->connect, $sql);
        }
        function deleteproduct($id){
            $sql="DELETE FROM product where code='$id' ";
            return mysqli_query($this->connect, $sql);
        }


        function editcat($id){
            $sql="SELECT * FROM add_category WHERE cat_id='$id'";
            return mysqli_query($this->connect, $sql);
        }
        function editsubcat($id){
            $sql="SELECT * FROM sub_category WHERE id='$id'";
            return mysqli_query($this->connect, $sql);
        }
        function editbrand($id){
            $sql="SELECT * FROM add_brand WHERE id='$id'";
            return mysqli_query($this->connect, $sql);
        }
        function editproduct($id){
            $sql="SELECT * FROM product WHERE code='$id'";
            return mysqli_query($this->connect, $sql);
        }
        

        function updatecategory($cat_name, $cat_pic, $id){
            $sql="UPDATE add_category SET category='$cat_name', pic='$cat_pic' WHERE cat_id='$id'";
            return mysqli_query($this->connect, $sql);
        }
        function updatesubcategory($cat_name, $subcat_name, $subcat_pic, $id ){
            $sql="UPDATE sub_category SET category='$cat_name', subcategory='$subcat_name', pic='$subcat_pic' WHERE id='$id' ";
            return mysqli_query($this->connect, $sql);
        }
        function updatebrand($cat_name, $subcat_name, $brand_name, $brand_pic, $id ){
            $sql="UPDATE add_brand SET brand='$brand_name',  subcategory='$subcat_name', category='$cat_name', pic='$brand_pic' WHERE id='$id' ";
            return mysqli_query($this->connect, $sql);
        }
        function updateproduct($pro_name, $pro_title, $pro_slug, $pro_keyword, $pro_category,
            $pro_subcategory, $pro_brand,  $pro_org_price, $pro_disc_price, $pro_shortdescription, $pro_longdescription, 
            $pro_size, $pro_color, $pro_gst, $pro_disc, $pro_deliverycharge, $pro_pic,  $pro_slider_pic, $id){

            $sql="UPDATE `product` SET name='$pro_name', `title`='$pro_title', `slug`='$pro_slug', `keywords`='$pro_keyword', `category`='$pro_category', 
            `subcategory`='$pro_subcategory', `brand`='$pro_brand', `original_price`='$pro_org_price', `discount_price`='$pro_disc_price', `short_description`='$pro_shortdescription', `long_description`='$pro_longdescription', `size`='$pro_size', 
            `colors`='$pro_color', `gst`='$pro_gst', discount='$pro_disc', `delivery_charge`='$pro_deliverycharge', `pic`='$pro_pic', `slider_pic`='$pro_slider_pic' WHERE code='$id'";        
            return mysqli_query($this->connect, $sql);
        }

        function order(){
            $sql="SELECT * FROM order_details ";
            return mysqli_query($this->connect, $sql);
        }

        function deletelatestorder($id){
            $sql= "DELETE FROM order_details WHERE id='$id'";
            return mysqli_query($this->connect, $sql);
        }


    }

    

    $admin_obj= new admin_link();
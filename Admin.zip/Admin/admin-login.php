<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <!-- Link Bootstrap CSS -->
    <link rel="stylesheet" href="bootsrap_file\bootstrap.css">
</head>

<body>
    <div class="container  rounded " style="margin-top:150px;">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header p-3 text-center  bg-primary text-">
                        <h4 class="font-weight-bold text-white " style="font-size: 40px;">Admin Login</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" action="admin-code.php">
                            <div class="form-group my-3">
                                <label class="font-weight-bold" for="username">Email</label>
                                <input type="text" name="email" class="form-control" id="username" placeholder="Enter your username">
                            </div>
                            <div class="form-group my-4">
                                <label class="font-weight-bold" for="password">Password</label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Enter your password">
                            </div>
                            <button type="submit" class="btn btn-primary my-3 font-weight-bold py-2 px-3" name="loginbtn">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Link Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>

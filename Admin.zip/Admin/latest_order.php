<?php
include('header.php');
?>

<div class="content-wrapper">
    
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Latest Orders</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item ">Orders</li>
              <li class="breadcrumb-item active">Latest Orders</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    

    <!-- Main content -->
    <section class="content">
      <div class="row">   <!--for grid-->

        <div class="col-lg-1"></div>
        <!-- main contained -->

        <div class="col-lg-10">
          <!-- <div class='card'> -->
            <div class="card-header bg-success text-light text-center mb-3">
              <h5><strong>Orders</strong></h5>
            </div>
             
             
                    <div class="card">
                      
                      <div class="card-body ">
                        <table class="table table-bordered">
                          <thead class="table-primary">
                            <th>Sno</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Pincode</th>
                            <th>Contact</th>
                            <th>Date & Time</th>

                            <th>Action</th>
                          </thead>

                          <tbody>
                            <?php
                              $res=$admin_obj->order();
                              if(mysqli_num_rows($res)>0){
                                $sno=1;
                                while($row=mysqli_fetch_assoc($res)){
                                 
                                  ?>
                                  <tr>
                                    <td><?php echo $sno;?></td>
                                    <td><?php echo $row['username'];?></td>
                                    <td><?php echo $row['email'];?></td>
                                    <td><?php echo $row['address'];?>" </td>
                                    <td><?php echo $row['pincode'];?>" </td>
                                    <td><?php echo $row['contact'];?>" </td>
                                    <td><?php echo $row['date_time'];?>"</td>


                                    <td class="btn-group"><a href="update-subcategory.php?id=<?php echo $row['id'];?>&do=updatesubcat" class="btn btn-warning">Edit</a>&nbsp;
                                    <a href="admin-code.php?id=<?php echo $row['id'];?>& do=deleteorder" class="btn btn-danger">Delete</a></td>
                                    

                                  </tr>
                                  <?php
                                  $sno++; }
                              }
                              
                            ?>
                          </tbody>
                          <tfoot>
                            <tr>
                            <th>Sno</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Pincode</th>
                            <th>Contact</th>
                            <th>Date & Time</th>

                            <th>Action</th>

                            </tr>
                          </tfoot>
                        </table>
                      </div>
                  </div>
                
                  <?php
             
              ?>
          </div>
        </div>  
           
        <div class="col-lg-1"></div>
      </div>
    </section>
    <!-- /.content -->
  </div>





<?php include "footer.php";?>
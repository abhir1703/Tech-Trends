<?php include "header.php";?>


<div class="content-wrapper">
    
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Products</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item ">Products</li>
              <li class="breadcrumb-item active">Add Products</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-2"></div>
        
        <div class="col-lg-8">
          <div class="card">
            <div class="card-header bg-primary text-center card-title">Products</div>
            <!-- card-body -->
            <div class="card-body">
              
              <form action="admin-code.php" method="post" enctype="multipart/form-data" multiple>
                  <!-- body part-1 -->

                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="">Product</label>
                      <input class="form-control" type="text " name="name" placeholder="Type the product Name">
                    </div>

                    <div class="form-group">
                      <label for="">Title</label>
                      <input class="form-control" type="text " name="title" placeholder="Type the product Title">
                    </div> 

                    <div class="form-group">
                      <label for="">Pic</label>
                      <input class="form-control" type="file" name="pic" placeholder="Type the product Pic">
                    </div>

                    <div class="form-group">
                      <label for="">Original Price</label>
                      <input class="form-control" type="text " name="original_price" placeholder="Type the product Original Price">
                    </div>
                    <div class="form-group">
                      <label for="">Discount Price</label>
                      <input class="form-control" type="text " name="discount_price" placeholder="Type the product Discount Price">
                    </div>
                    
                    <div class="form-group">
                      <label for="">Slug</label>
                      <input class="form-control" type="text " name="slug" placeholder="Type the product Slug">
                    </div>

                    <div class="form-group">
                      <label for="">Keyword</label>
                      <input class="form-control" type="text " name="keyword" placeholder="Type the product Keyword">
                    </div>

                    <div class="form-group">
                      <label for="">Size</label>
                      <input class="form-control" type="number " name="size" placeholder="Type the product Size">
                    </div>

                    <div class="form-group">
                      <label for="">Color</label>
                      <input class="form-control" type="text " name="color" placeholder="Type the product Color">
                    </div>

                  </div>
                  <!-- /.bodt part -1 end -->

                  <!-- body part-2 -->
                  <div class="col-lg-6">

                   <!-- Add category -->
                    <div class="form-group">
                      <label for="">Category</label>
                      <select class="form-control" name="category" id="">
                      <option value="">---Select Category---</option>

                      <?php
                      
                        $cres=$admin_obj->list_category();
                        if(mysqli_num_rows($cres)>0){
                          while($crow=mysqli_fetch_assoc($cres)){
                          ?>
                          <option value="">
                            <?php echo $crow['category'];?>
                          </option>
                          <?php
                          }
                        }
                      ?>
                      </select>
                    </div>
                    <!-- end category dropdown -->

                    <!-- Add Sub Category Dropdown -->
                    <div class="form-group">
                      <label for="">Subcategory</label>
                      <!-- <select class="form-control" name="subcategory" id="">
                        <option value="">---Select Sub Category---</option>

                        <?php
                          $sres=$admin_obj->list_subcategory();
                          if(mysqli_num_rows($sres)>0){
                            while($srow=mysqli_fetch_assoc($sres)){
                              // if($crow['category']==$srow['category']){
                              ?>
                              <option>
                               <?php echo $srow['subcategory'];?>
                              </option>
                              <?php
                              
                            }
                          }
                        ?>
                      </select> -->
                      <input class="form-control" type="text " name="subcategory" placeholder="Type the product Sub Category">

                    </div>
                    <!-- end Sub Category dropdown -->

                    <!-- Brand Dropdown -->
                    <div class="form-group">
                      <label for="">Brand</label>
                        <!-- <select class="form-control" name="brand" id="">
                          <option value="">---Select the Brand--- </option>
                          
                            <?php
                              $bres=$admin_obj->viewbrand();
                              if(mysqli_num_rows($bres)>0){
                                while($brow=mysqli_fetch_assoc($bres)){
                                  ?>
                                  <option value="">
                                    <?php echo $brow['brand'];?>
                                  </option>
                                  <?php
                                  
                                }
                              }

                            ?>
                          

                         
                        </select> -->
                        <input class="form-control" type="text " name="brand" placeholder="Type the product Brand">

                    </div>
                    <!-- End Brand Dropdown -->


                    <div class="form-group">
                      <label for="">Short Description</label>
                      <input class="form-control" type="text " name="shortdescription" placeholder="Type the product Short Description">
                    </div>

                    <div class="form-group">
                      <label for="">Long Description</label>
                      <input class="form-control" type="text " name="longdescription" placeholder="Type the product Long Description">
                    </div>

                  
                    <div class="form-group">
                      <label for="">GST</label>
                      <input class="form-control" type="text " name="gst" placeholder="Type the product GST">
                    </div>
                    <div class="form-group">
                      <label for="">Discount</label>
                      <input class="form-control" type="text " name="discount" placeholder="Type the product discount">
                    </div>

                    <div class="form-group">
                      <label for="">Delivery Charge</label>
                      <input class="form-control" type="number" name="deliverycharge" placeholder="Type the product Delivery Charge">
                    </div>

                  

                    <div class="form-group">
                      <label for="">Slider Pic</label>
                      <input class="form-control" type="file" name="sliderpic" multiple placeholder="Type the product Slider Pic">
                    </div>
                    <input type="hidden" name="id" id="">

                  </div>
                  <!-- /.body part -2 end -->
                </div>
                <div class="form-group">
                  <input class="btn btn-primary form-control" type="submit" name="addproduct" value="Add Products">
                </div>

                <!-- /. class row end -->
              </form>
      
            </div>
          </div>
        </div>

        <div class="col-lg-2"></div>

      </div>

    </section>
    <!-- /.content -->
  </div>





<?php include "footer.php";?>
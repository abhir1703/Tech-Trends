<?php

include("admin_connection.php"); 


// for admin login


if(isset($_POST['loginbtn'])){
    $adminemail=$_POST['email'];
    $adminpass=$_POST['password'];
    $result=$admin_obj->admin_login($adminemail,$adminpass);
    if($result){
    if(mysqli_num_rows($result)>0){
        $admin=mysqli_fetch_assoc($result);
        $_SESSION['adminid']=$admin['email'];
        $_SESSION['adminname']=$admin['name'];
        ?><script>
            alert("Welcome Admin Store");
            window.location.href="index.php";
        </script>
        <?php
    // }
}
    else{
        ?><script>
            alert("invalid entry");
            window.location.href="admin-login.php";
    </script>
    <?php
    }
}
}


// for admin logout


if(isset($_REQUEST['dologout']) && $_REQUEST['dologout']=="logoutbtn"){
    // session_start();
    session_destroy();
    ?>
    <script>
        alert("Admin LogOut");
        window.location.href="admin-login.php";
    </script>
    <?php
}

// for add category

if(isset($_POST['addcategory'])){
    $cat_name=$_POST['category'];

    $file=$_FILES['pic']['name'];
    $folder='uploads/';
    $cat_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $cat_pic);

    if($admin_obj->add_category($cat_name, $cat_pic)){
        ?>
        <script>
            alert("Category Added")
            window.location.href="add-category.php"
        </script>
        <?php
    }

}

// for add subcategory

if(isset($_POST['addsubcategory'])){
    
    $sub_cat_name=$_POST['subcategory'];
    $cat_name=$_POST['category'];

    $folder="uploads/";
    $file=$_FILES['pic']['name'];
    $sub_cat_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'],$sub_cat_pic);
    

    if($admin_obj->add_sub_category($sub_cat_name, $cat_name, $sub_cat_pic)){
        ?>
        <script>
            alert("Record Added");
            window.location.href="add-sub-category.php";
        </script>
        <?php
    }
}


// ---Add Brand---

if(isset($_POST['addbrand'])){
    
    $brand_name=$_POST['brand'];
    $sub_cat_name=$_POST['subcategory'];
    $cat_name=$_POST['category'];

    $folder="uploads/";
    $file=$_FILES['pic']['name'];
    $pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'],$pic);
    

    if($admin_obj->add_brands($brand_name, $sub_cat_name, $cat_name, $pic)){
        ?>
        <script>
            alert("Record Added");
            window.location.href="add-brand.php";
        </script>
        <?php
    }
}

// Add Product Data

if(isset($_POST['addproduct'])){
    $pro_name=$_POST['name'];
    $pro_title=$_POST['title'];
    $pro_org_price=$_POST['original_price'];
    $pro_disc_price=$_POST['discount_price'];
    $pro_slug=$_POST['slug'];
    $pro_keyword=$_POST['keyword'];
    $pro_brand=$_POST['brand'];
    $pro_size=$_POST['size'];
    $pro_color=$_POST['color'];
    $pro_category=$_POST['category'];
    $pro_subcategory=$_POST['subcategory'];
    $pro_shortdescription=$_POST['shortdescription'];
    $pro_longdescription=$_POST['longdescription'];
    $pro_gst=$_POST['gst'];
    $pro_disc=$_POST['discount'];

    $pro_deliverycharge=$_POST['deliverycharge'];
    // ---pic---
    $folder="uploads/";
    $file=$_FILES['pic']['name'];
    $pro_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $pro_pic);
    // ---slider pics---
    $folder="uploads/";
    $file=$_FILES['sliderpic']['name'];
    $pro_slider_pic=$folder.basename($file);
    move_uploaded_file($_FILES['sliderpic']['tmp_name'], $pro_slider_pic);

    if($admin_obj->add_products($pro_name, $pro_title, 
    $pro_slug, $pro_keyword, $pro_category, $pro_subcategory,  $pro_brand, $pro_org_price, $pro_disc_price,
    $pro_shortdescription, $pro_longdescription, $pro_size,  $pro_color, $pro_gst, $pro_disc, 
    $pro_deliverycharge, $pro_pic,  $pro_slider_pic)){
        ?>
        <script>
            alert("Record Added");
            window.location.href="add-product.php";
        </script>
        <?php
    }
}


// Delete Category

if(isset($_REQUEST['id'])  && isset($_REQUEST['do'])  && $_REQUEST['do']=='deletecat'){
    $id=$_REQUEST['id'];
    if($admin_obj->deletecategory($id)){
        ?>
        <script>
            confirm("Do You want to Delete");
            window.location.href="View-category.php";
        </script>
        <?php
    }

}

// ---Delete Sub-Category---

if(isset($_REQUEST['id'])  && isset($_REQUEST['do'])  && $_REQUEST['do']=='deletesubcat'){
    $id=$_REQUEST['id'];
    if($admin_obj->deletesubcategory($id)){
        ?>
        <script>
            confirm("Do You want to Delete");
            window.location.href="View-sub-category.php";
        </script>
        <?php
    }

}


// ---Delete Brand---

if(isset($_REQUEST['id'])  && isset($_REQUEST['do'])  && $_REQUEST['do']=='deletebrand'){
    $id=$_REQUEST['id'];
    if($admin_obj->deletebrand($id)){
        ?>
        <script>
            confirm("Do You want to Delete");
            window.location.href="View-brand.php";
        </script>
        <?php
    }

}


// ---Delete Product---

if(isset($_REQUEST['id'])  && isset($_REQUEST['do'])  && $_REQUEST['do']=='deleteproduct'){
    $id=$_REQUEST['id'];
    if($admin_obj->deleteproduct($id)){
        ?>
        <script>
            confirm("Do You want to Delete");
            window.location.href="View-products.php";
        </script>
        <?php
    }

}


// ---Category Updated---

if(isset($_POST['updatecat'])){
    $cat_name=$_POST['category'];
    $id=$_POST['id'];
    $file=$_FILES['pic']['name'];
    $folder="uploads/";
    $cat_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $cat_pic);

    if($admin_obj->updatecategory($cat_name, $cat_pic,  $id)){
        ?>
        <script>
            alert("Record Updated");
            window.location.href="View-category.php";
        </script>
        <?php
    }
}


// ---Subcategory Updated---

if(isset($_POST['updatesubcategory'])){
    $cat_name=$_POST['category'];
    $subcat_name=$_POST['subcategory'];
    $file=$_FILES['pic']['name'];
    $folder="uploads/";
    $subcat_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $subcat_pic);
    $id=$_POST['id'];
    if($admin_obj->updatesubcategory($cat_name, $subcat_name, $subcat_pic, $id)){
        ?>
        <script>
            alert("Record Updated");
            window.location.href="View-sub-category.php";
        </script>
        <?php
    }
}

// ---Brand Updated---

if(isset($_POST['updatebrand'])){
    $cat_name=$_POST['category'];
    $subcat_name=$_POST['subcategory'];
    $brand_name=$_POST['brand'];
    $file=$_FILES['pic']['name'];
    $folder="uploads/";
    $brand_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $brand_pic);
    $id=$_POST['id'];
    if($admin_obj->updatebrand($cat_name, $subcat_name, $brand_name, $brand_pic, $id)){
        ?>
        <script>
            alert("Record Updated");
            window.location.href="View-brand.php";
        </script>
        <?php
    }
}


// ---Update Product---

if(isset($_POST['updateproduct'])){
    $id=$_POST['id'];
    $pro_name=$_POST['name'];
    $pro_title=$_POST['title'];
    $pro_org_price=$_POST['original_price'];
    $pro_disc_price=$_POST['discount_price'];
    $pro_slug=$_POST['slug'];
    $pro_keyword=$_POST['keyword'];
    $pro_brand=$_POST['brand'];
    $pro_size=$_POST['size'];
    $pro_color=$_POST['color'];
    $pro_category=$_POST['category'];
    $pro_subcategory=$_POST['subcategory'];
    $pro_shortdescription=$_POST['shortdescription'];
    $pro_longdescription=$_POST['longdescription'];
    $pro_gst=$_POST['gst'];
    $pro_disc=$_POST['discount'];
    $pro_deliverycharge=$_POST['deliverycharge'];
    // ---pic---
    $folder="uploads/";
    $file=$_FILES['pic']['name'];
    $pro_pic=$folder.basename($file);
    move_uploaded_file($_FILES['pic']['tmp_name'], $pro_pic);
    // ---slider pics---
    $folder="uploads/";
    $file=$_FILES['sliderpic']['name'];
    $pro_slider_pic=$folder.basename($file);
    move_uploaded_file($_FILES['sliderpic']['tmp_name'], $pro_slider_pic);

    if($admin_obj->updateproduct($pro_name, $pro_title, 
    $pro_slug, $pro_keyword, $pro_category, $pro_subcategory,  $pro_brand, $pro_org_price, $pro_disc_price,
    $pro_shortdescription, $pro_longdescription, $pro_size,  $pro_color, $pro_gst, $pro_disc,
    $pro_deliverycharge, $pro_pic,  $pro_slider_pic, $id)){
        ?>
        <script>
            alert("Record Updated");
            window.location.href="view-products.php";
        </script>
        <?php
    }
}


// Delete Latest Orders
if(isset($_REQUEST['id']) && isset($_REQUEST['do']) && $_REQUEST['do']=='deleteorder') {
    $id=$_REQUEST['id'];

    if($res=$admin_obj->deletelatestorder($id)){
        ?>
        <script>
            confirm('Do You want to Delete')
            window.location.href='latest_order.php'
        </script>
        <?php
    }
}
?>